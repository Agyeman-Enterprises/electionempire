// ═══════════════════════════════════════════════════════════════════════════════
// ELECTION EMPIRE - News System Interfaces
// Shared interfaces for the news translation and fallback systems
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;

namespace ElectionEmpire.News
{
    /// <summary>
    /// Political categories for news classification
    /// </summary>
    public enum PoliticalCategory
    {
        General,
        HealthcarePolicy,
        EconomicPolicy,
        Immigration,
        ClimateEnvironment,
        Education,
        ForeignPolicy,
        Defense,
        CriminalJustice,
        SocialIssues,
        Election,
        Scandal,
        Crisis
    }
    
    /// <summary>
    /// Player alignment tracking for news contextualization
    /// </summary>
    [Serializable]
    public struct PlayerAlignment
    {
        public int LawChaos;  // -100 (Lawful) to +100 (Chaotic)
        public int GoodEvil;  // -100 (Good) to +100 (Evil)
        
        public string GetAlignmentName()
        {
            string lawChaosName = LawChaos switch
            {
                < -33 => "Lawful",
                > 33 => "Chaotic",
                _ => "Neutral"
            };
            
            string goodEvilName = GoodEvil switch
            {
                < -33 => "Good",
                > 33 => "Evil",
                _ => "Neutral"
            };
            
            if (lawChaosName == "Neutral" && goodEvilName == "Neutral")
                return "True Neutral";
            
            return $"{lawChaosName} {goodEvilName}";
        }
    }
    
    /// <summary>
    /// Main interface for reading game state - used by news translation system.
    /// </summary>
    public interface IGameStateProvider
    {
        int GetPlayerOfficeTier();
        string GetPlayerOfficeTitle();
        string GetPlayerName();
        string GetPlayerParty();
        string GetPlayerState();
        int GetCurrentTurn();
        int GetTurnsUntilElection();
        float GetPlayerApproval();
        PlayerAlignment GetPlayerAlignment();
        string GetPlayerPartyPosition(PoliticalCategory category);
        bool IsChaosModeEnabled();
    }
}
