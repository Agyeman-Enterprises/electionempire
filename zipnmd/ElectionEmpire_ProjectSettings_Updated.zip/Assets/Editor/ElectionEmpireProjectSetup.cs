using UnityEngine;
using UnityEditor;
using System.IO;

/// <summary>
/// Editor script to set up the Election Empire project folder structure.
/// Run from Unity menu: Tools > Election Empire > Setup Project Structure
/// </summary>
public class ElectionEmpireProjectSetup : EditorWindow
{
    [MenuItem("Tools/Election Empire/Setup Project Structure")]
    public static void SetupProjectStructure()
    {
        // Create main folders
        CreateFolderIfNotExists("Assets/Scenes");
        CreateFolderIfNotExists("Assets/Scripts");
        CreateFolderIfNotExists("Assets/Prefabs");
        CreateFolderIfNotExists("Assets/Art");
        CreateFolderIfNotExists("Assets/Audio");
        CreateFolderIfNotExists("Assets/Data");
        CreateFolderIfNotExists("Assets/Resources");
        CreateFolderIfNotExists("Assets/StreamingAssets");
        CreateFolderIfNotExists("Assets/Plugins");
        CreateFolderIfNotExists("Assets/Editor");
        CreateFolderIfNotExists("Assets/Animations");
        CreateFolderIfNotExists("Assets/Materials");
        CreateFolderIfNotExists("Assets/Shaders");
        CreateFolderIfNotExists("Assets/Fonts");
        CreateFolderIfNotExists("Assets/Localization");

        // Scene subfolders
        CreateFolderIfNotExists("Assets/Scenes/Core");
        CreateFolderIfNotExists("Assets/Scenes/CharacterCreation");
        CreateFolderIfNotExists("Assets/Scenes/Gameplay");
        CreateFolderIfNotExists("Assets/Scenes/Events");
        CreateFolderIfNotExists("Assets/Scenes/Election");
        CreateFolderIfNotExists("Assets/Scenes/Legacy");
        CreateFolderIfNotExists("Assets/Scenes/Tutorial");
        CreateFolderIfNotExists("Assets/Scenes/Multiplayer");

        // Script subfolders
        CreateFolderIfNotExists("Assets/Scripts/Core");
        CreateFolderIfNotExists("Assets/Scripts/Core/GameManager");
        CreateFolderIfNotExists("Assets/Scripts/Core/SaveSystem");
        CreateFolderIfNotExists("Assets/Scripts/Core/SceneManagement");
        CreateFolderIfNotExists("Assets/Scripts/Core/EventSystem");
        CreateFolderIfNotExists("Assets/Scripts/Core/AudioManager");
        CreateFolderIfNotExists("Assets/Scripts/Character");
        CreateFolderIfNotExists("Assets/Scripts/Character/Creation");
        CreateFolderIfNotExists("Assets/Scripts/Character/Stats");
        CreateFolderIfNotExists("Assets/Scripts/Character/Traits");
        CreateFolderIfNotExists("Assets/Scripts/Character/Background");
        CreateFolderIfNotExists("Assets/Scripts/Campaign");
        CreateFolderIfNotExists("Assets/Scripts/Campaign/Actions");
        CreateFolderIfNotExists("Assets/Scripts/Campaign/Polling");
        CreateFolderIfNotExists("Assets/Scripts/Campaign/Fundraising");
        CreateFolderIfNotExists("Assets/Scripts/Governance");
        CreateFolderIfNotExists("Assets/Scripts/Governance/Policy");
        CreateFolderIfNotExists("Assets/Scripts/Governance/Staff");
        CreateFolderIfNotExists("Assets/Scripts/Governance/Budget");
        CreateFolderIfNotExists("Assets/Scripts/Election");
        CreateFolderIfNotExists("Assets/Scripts/Election/Voting");
        CreateFolderIfNotExists("Assets/Scripts/Election/Results");
        CreateFolderIfNotExists("Assets/Scripts/Scandal");
        CreateFolderIfNotExists("Assets/Scripts/Scandal/Engine");
        CreateFolderIfNotExists("Assets/Scripts/Scandal/Templates");
        CreateFolderIfNotExists("Assets/Scripts/Scandal/Response");
        CreateFolderIfNotExists("Assets/Scripts/Crisis");
        CreateFolderIfNotExists("Assets/Scripts/Media");
        CreateFolderIfNotExists("Assets/Scripts/Media/Headlines");
        CreateFolderIfNotExists("Assets/Scripts/Media/SocialMedia");
        CreateFolderIfNotExists("Assets/Scripts/Media/NewsIntegration");
        CreateFolderIfNotExists("Assets/Scripts/Alignment");
        CreateFolderIfNotExists("Assets/Scripts/Resources");
        CreateFolderIfNotExists("Assets/Scripts/Legacy");
        CreateFolderIfNotExists("Assets/Scripts/AI");
        CreateFolderIfNotExists("Assets/Scripts/AI/Opponents");
        CreateFolderIfNotExists("Assets/Scripts/AI/Caricature");
        CreateFolderIfNotExists("Assets/Scripts/Multiplayer");
        CreateFolderIfNotExists("Assets/Scripts/Multiplayer/Tournament");
        CreateFolderIfNotExists("Assets/Scripts/Multiplayer/Matchmaking");
        CreateFolderIfNotExists("Assets/Scripts/UI");
        CreateFolderIfNotExists("Assets/Scripts/UI/Screens");
        CreateFolderIfNotExists("Assets/Scripts/UI/Components");
        CreateFolderIfNotExists("Assets/Scripts/UI/Popups");
        CreateFolderIfNotExists("Assets/Scripts/UI/HUD");
        CreateFolderIfNotExists("Assets/Scripts/Utilities");
        CreateFolderIfNotExists("Assets/Scripts/Data");
        CreateFolderIfNotExists("Assets/Scripts/Analytics");
        CreateFolderIfNotExists("Assets/Scripts/Monetization");
        CreateFolderIfNotExists("Assets/Scripts/Steam");
        CreateFolderIfNotExists("Assets/Scripts/Localization");

        // Prefab subfolders
        CreateFolderIfNotExists("Assets/Prefabs/Characters");
        CreateFolderIfNotExists("Assets/Prefabs/Characters/Portraits");
        CreateFolderIfNotExists("Assets/Prefabs/Characters/Caricatures");
        CreateFolderIfNotExists("Assets/Prefabs/UI");
        CreateFolderIfNotExists("Assets/Prefabs/UI/Screens");
        CreateFolderIfNotExists("Assets/Prefabs/UI/Popups");
        CreateFolderIfNotExists("Assets/Prefabs/UI/Components");
        CreateFolderIfNotExists("Assets/Prefabs/UI/Cards");
        CreateFolderIfNotExists("Assets/Prefabs/UI/Buttons");
        CreateFolderIfNotExists("Assets/Prefabs/Effects");
        CreateFolderIfNotExists("Assets/Prefabs/Events");
        CreateFolderIfNotExists("Assets/Prefabs/Media");

        // Art subfolders
        CreateFolderIfNotExists("Assets/Art/Characters");
        CreateFolderIfNotExists("Assets/Art/Characters/Portraits");
        CreateFolderIfNotExists("Assets/Art/Characters/Expressions");
        CreateFolderIfNotExists("Assets/Art/Characters/Bodies");
        CreateFolderIfNotExists("Assets/Art/Backgrounds");
        CreateFolderIfNotExists("Assets/Art/UI");
        CreateFolderIfNotExists("Assets/Art/UI/Icons");
        CreateFolderIfNotExists("Assets/Art/UI/Buttons");
        CreateFolderIfNotExists("Assets/Art/UI/Panels");
        CreateFolderIfNotExists("Assets/Art/UI/Cards");
        CreateFolderIfNotExists("Assets/Art/Icons");
        CreateFolderIfNotExists("Assets/Art/Icons/Resources");
        CreateFolderIfNotExists("Assets/Art/Icons/Traits");
        CreateFolderIfNotExists("Assets/Art/Icons/Backgrounds");
        CreateFolderIfNotExists("Assets/Art/Icons/Alignment");
        CreateFolderIfNotExists("Assets/Art/Effects");
        CreateFolderIfNotExists("Assets/Art/Maps");
        CreateFolderIfNotExists("Assets/Art/Logo");
        CreateFolderIfNotExists("Assets/Art/Splash");

        // Audio subfolders
        CreateFolderIfNotExists("Assets/Audio/Music");
        CreateFolderIfNotExists("Assets/Audio/Music/Menu");
        CreateFolderIfNotExists("Assets/Audio/Music/Campaign");
        CreateFolderIfNotExists("Assets/Audio/Music/Crisis");
        CreateFolderIfNotExists("Assets/Audio/Music/Victory");
        CreateFolderIfNotExists("Assets/Audio/SFX");
        CreateFolderIfNotExists("Assets/Audio/SFX/UI");
        CreateFolderIfNotExists("Assets/Audio/SFX/Events");
        CreateFolderIfNotExists("Assets/Audio/SFX/Notifications");
        CreateFolderIfNotExists("Assets/Audio/Ambience");
        CreateFolderIfNotExists("Assets/Audio/Voice");

        // Data subfolders (ScriptableObjects)
        CreateFolderIfNotExists("Assets/Data/Characters");
        CreateFolderIfNotExists("Assets/Data/Characters/Backgrounds");
        CreateFolderIfNotExists("Assets/Data/Characters/Traits");
        CreateFolderIfNotExists("Assets/Data/Scandals");
        CreateFolderIfNotExists("Assets/Data/Scandals/Templates");
        CreateFolderIfNotExists("Assets/Data/Policies");
        CreateFolderIfNotExists("Assets/Data/Events");
        CreateFolderIfNotExists("Assets/Data/Events/Political");
        CreateFolderIfNotExists("Assets/Data/Events/Crisis");
        CreateFolderIfNotExists("Assets/Data/Events/Random");
        CreateFolderIfNotExists("Assets/Data/Media");
        CreateFolderIfNotExists("Assets/Data/Media/Headlines");
        CreateFolderIfNotExists("Assets/Data/Media/Outlets");
        CreateFolderIfNotExists("Assets/Data/VoterBlocs");
        CreateFolderIfNotExists("Assets/Data/Offices");
        CreateFolderIfNotExists("Assets/Data/Achievements");
        CreateFolderIfNotExists("Assets/Data/Legacy");
        CreateFolderIfNotExists("Assets/Data/Dialogue");
        CreateFolderIfNotExists("Assets/Data/Balance");

        // Localization subfolders
        CreateFolderIfNotExists("Assets/Localization/en-US");
        CreateFolderIfNotExists("Assets/Localization/es-ES");
        CreateFolderIfNotExists("Assets/Localization/fr-FR");
        CreateFolderIfNotExists("Assets/Localization/de-DE");
        CreateFolderIfNotExists("Assets/Localization/zh-CN");
        CreateFolderIfNotExists("Assets/Localization/ja-JP");
        CreateFolderIfNotExists("Assets/Localization/ko-KR");
        CreateFolderIfNotExists("Assets/Localization/pt-BR");
        CreateFolderIfNotExists("Assets/Localization/ru-RU");
        CreateFolderIfNotExists("Assets/Localization/it-IT");
        CreateFolderIfNotExists("Assets/Localization/pl-PL");

        AssetDatabase.Refresh();
        Debug.Log("Election Empire project structure created successfully!");
        EditorUtility.DisplayDialog("Setup Complete", 
            "Election Empire project structure has been created.\n\n" +
            "Next steps:\n" +
            "1. Create scenes in Assets/Scenes/ folders\n" +
            "2. Update EditorBuildSettings with actual scene GUIDs\n" +
            "3. Import your art assets into Assets/Art/\n" +
            "4. Add audio files to Assets/Audio/", 
            "OK");
    }

    [MenuItem("Tools/Election Empire/Create Empty Scenes")]
    public static void CreateEmptyScenes()
    {
        // Core scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/Core/BootLoader.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Core/MainMenu.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Core/Settings.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Core/Credits.unity");

        // Character Creation scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/CharacterCreation/CharacterCreation.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/CharacterCreation/BackgroundSelection.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/CharacterCreation/TraitSelection.unity");

        // Gameplay scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/Gameplay/CampaignHQ.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Gameplay/CampaignTrail.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Gameplay/Governance.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Gameplay/PolicyCenter.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Gameplay/StaffManagement.unity");

        // Event scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/Events/Debate.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Events/Rally.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Events/PressConference.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Events/Interview.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Events/Crisis.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Events/Scandal.unity");

        // Election scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/Election/ElectionDay.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Election/Results.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Election/Victory.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Election/Defeat.unity");

        // Legacy scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/Legacy/LegacyScreen.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Legacy/HallOfFame.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Legacy/DynastyTree.unity");

        // Tutorial scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/Tutorial/TutorialIntro.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Tutorial/TutorialCampaign.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Tutorial/TutorialGovernance.unity");

        // Multiplayer scenes
        CreateEmptySceneIfNotExists("Assets/Scenes/Multiplayer/Lobby.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Multiplayer/Tournament.unity");
        CreateEmptySceneIfNotExists("Assets/Scenes/Multiplayer/Matchmaking.unity");

        AssetDatabase.Refresh();
        Debug.Log("Empty scenes created successfully!");
        EditorUtility.DisplayDialog("Scenes Created", 
            "Empty scenes have been created.\n\n" +
            "The Build Settings will need to be updated to reference the actual scene GUIDs.\n" +
            "Go to File > Build Settings and re-add the scenes.", 
            "OK");
    }

    private static void CreateFolderIfNotExists(string path)
    {
        if (!AssetDatabase.IsValidFolder(path))
        {
            string parentFolder = Path.GetDirectoryName(path).Replace("\\", "/");
            string newFolderName = Path.GetFileName(path);
            
            // Ensure parent exists
            if (!AssetDatabase.IsValidFolder(parentFolder))
            {
                CreateFolderIfNotExists(parentFolder);
            }
            
            AssetDatabase.CreateFolder(parentFolder, newFolderName);
        }
    }

    private static void CreateEmptySceneIfNotExists(string scenePath)
    {
        if (!File.Exists(scenePath))
        {
            // Ensure directory exists
            string directory = Path.GetDirectoryName(scenePath);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            // Create a minimal valid Unity scene file
            string sceneName = Path.GetFileNameWithoutExtension(scenePath);
            string sceneContent = @"%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!29 &1
OcclusionCullingSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 2
  m_OcclusionBakeSettings:
    smallestOccluder: 5
    smallestHole: 0.25
    backfaceThreshold: 100
  m_SceneGUID: 00000000000000000000000000000000
  m_OcclusionCullingData: {fileID: 0}
--- !u!104 &2
RenderSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 10
  m_Fog: 0
  m_FogColor: {r: 0.5, g: 0.5, b: 0.5, a: 1}
  m_FogMode: 3
  m_FogDensity: 0.01
  m_LinearFogStart: 0
  m_LinearFogEnd: 300
  m_AmbientSkyColor: {r: 0.212, g: 0.227, b: 0.259, a: 1}
  m_AmbientEquatorColor: {r: 0.114, g: 0.125, b: 0.133, a: 1}
  m_AmbientGroundColor: {r: 0.047, g: 0.043, b: 0.035, a: 1}
  m_AmbientIntensity: 1
  m_AmbientMode: 3
  m_SubtractiveShadowColor: {r: 0.42, g: 0.478, b: 0.627, a: 1}
  m_SkyboxMaterial: {fileID: 0}
  m_HaloStrength: 0.5
  m_FlareStrength: 1
  m_FlareFadeSpeed: 3
  m_HaloTexture: {fileID: 0}
  m_SpotCookie: {fileID: 10001, guid: 0000000000000000e000000000000000, type: 0}
  m_DefaultReflectionMode: 0
  m_DefaultReflectionResolution: 128
  m_ReflectionBounces: 1
  m_ReflectionIntensity: 1
  m_CustomReflection: {fileID: 0}
  m_Sun: {fileID: 0}
  m_UseRadianceAmbientProbe: 0
--- !u!157 &3
LightmapSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 12
  m_GIWorkflowMode: 1
  m_GISettings:
    serializedVersion: 2
    m_BounceScale: 1
    m_IndirectOutputScale: 1
    m_AlbedoBoost: 1
    m_EnvironmentLightingMode: 0
    m_EnableBakedLightmaps: 0
    m_EnableRealtimeLightmaps: 0
  m_LightmapEditorSettings:
    serializedVersion: 12
    m_Resolution: 2
    m_BakeResolution: 40
    m_AtlasSize: 1024
    m_AO: 0
    m_AOMaxDistance: 1
    m_CompAOExponent: 1
    m_CompAOExponentDirect: 0
    m_ExtractAmbientOcclusion: 0
    m_Padding: 2
    m_LightmapParameters: {fileID: 0}
    m_LightmapsBakeMode: 1
    m_TextureCompression: 1
    m_FinalGather: 0
    m_FinalGatherFiltering: 1
    m_FinalGatherRayCount: 256
    m_ReflectionCompression: 2
    m_MixedBakeMode: 2
    m_BakeBackend: 1
    m_PVRSampling: 1
    m_PVRDirectSampleCount: 32
    m_PVRSampleCount: 500
    m_PVRBounces: 2
    m_PVREnvironmentSampleCount: 500
    m_PVREnvironmentReferencePointCount: 2048
    m_PVRFilteringMode: 1
    m_PVRDenoiserTypeDirect: 1
    m_PVRDenoiserTypeIndirect: 1
    m_PVRDenoiserTypeAO: 1
    m_PVRFilterTypeDirect: 0
    m_PVRFilterTypeIndirect: 0
    m_PVRFilterTypeAO: 0
    m_PVREnvironmentMIS: 1
    m_PVRCulling: 1
    m_PVRFilteringGaussRadiusDirect: 1
    m_PVRFilteringGaussRadiusIndirect: 5
    m_PVRFilteringGaussRadiusAO: 2
    m_PVRFilteringAtrousPositionSigmaDirect: 0.5
    m_PVRFilteringAtrousPositionSigmaIndirect: 2
    m_PVRFilteringAtrousPositionSigmaAO: 1
    m_ExportTrainingData: 0
    m_TrainingDataDestination: TrainingData
    m_LightProbeSampleCountMultiplier: 4
  m_LightingDataAsset: {fileID: 0}
  m_LightingSettings: {fileID: 0}
--- !u!196 &4
NavMeshSettings:
  serializedVersion: 2
  m_ObjectHideFlags: 0
  m_BuildSettings:
    serializedVersion: 3
    agentTypeID: 0
    agentRadius: 0.5
    agentHeight: 2
    agentSlope: 45
    agentClimb: 0.4
    ledgeDropHeight: 0
    maxJumpAcrossDistance: 0
    minRegionArea: 2
    manualCellSize: 0
    cellSize: 0.16666667
    manualTileSize: 0
    tileSize: 256
    buildHeightMesh: 0
    maxJobWorkers: 0
    preserveTilesOutsideBounds: 0
    debug:
      m_Flags: 0
  m_NavMeshData: {fileID: 0}
";
            File.WriteAllText(scenePath, sceneContent);
        }
    }
}
