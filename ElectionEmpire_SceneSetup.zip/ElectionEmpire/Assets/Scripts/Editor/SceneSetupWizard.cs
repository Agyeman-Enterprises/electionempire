#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEngine.UI;
using UnityEditor.SceneManagement;
using TMPro;

namespace ElectionEmpire.Editor
{
    /// <summary>
    /// Editor wizard to quickly set up Election Empire scenes.
    /// Access from: Tools > Election Empire > Scene Setup Wizard
    /// </summary>
    public class SceneSetupWizard : EditorWindow
    {
        private enum SceneType
        {
            MainMenu,
            Game
        }
        
        private SceneType selectedSceneType = SceneType.MainMenu;
        private bool createCanvas = true;
        private bool createEventSystem = true;
        private bool createManagers = true;
        private bool createPanels = true;
        
        [MenuItem("Tools/Election Empire/Scene Setup Wizard")]
        public static void ShowWindow()
        {
            GetWindow<SceneSetupWizard>("Scene Setup Wizard");
        }
        
        private void OnGUI()
        {
            GUILayout.Label("Election Empire Scene Setup", EditorStyles.boldLabel);
            GUILayout.Space(10);
            
            EditorGUILayout.HelpBox(
                "This wizard will create the basic structure for Election Empire scenes.\n" +
                "Make sure you're in an empty or new scene before running.",
                MessageType.Info);
            
            GUILayout.Space(10);
            
            selectedSceneType = (SceneType)EditorGUILayout.EnumPopup("Scene Type", selectedSceneType);
            
            GUILayout.Space(5);
            
            createCanvas = EditorGUILayout.Toggle("Create UI Canvas", createCanvas);
            createEventSystem = EditorGUILayout.Toggle("Create Event System", createEventSystem);
            createManagers = EditorGUILayout.Toggle("Create Manager Objects", createManagers);
            createPanels = EditorGUILayout.Toggle("Create Panel Templates", createPanels);
            
            GUILayout.Space(20);
            
            if (GUILayout.Button("Setup Scene", GUILayout.Height(30)))
            {
                SetupScene();
            }
            
            GUILayout.Space(10);
            
            EditorGUILayout.HelpBox(
                "After setup:\n" +
                "1. Save the scene with the appropriate name\n" +
                "2. Add scene to Build Settings\n" +
                "3. Assign prefab/component references in inspectors",
                MessageType.None);
            
            GUILayout.Space(10);
            
            GUILayout.Label("Quick Actions", EditorStyles.boldLabel);
            
            if (GUILayout.Button("Open Build Settings"))
            {
                EditorWindow.GetWindow(System.Type.GetType("UnityEditor.BuildPlayerWindow,UnityEditor"));
            }
            
            if (GUILayout.Button("Create MainMenu Scene (New)"))
            {
                if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                {
                    var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                    selectedSceneType = SceneType.MainMenu;
                    SetupScene();
                    EditorSceneManager.SaveScene(scene, "Assets/Scenes/MainMenu.unity");
                }
            }
            
            if (GUILayout.Button("Create Game Scene (New)"))
            {
                if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                {
                    var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                    selectedSceneType = SceneType.Game;
                    SetupScene();
                    EditorSceneManager.SaveScene(scene, "Assets/Scenes/Game.unity");
                }
            }
        }
        
        private void SetupScene()
        {
            switch (selectedSceneType)
            {
                case SceneType.MainMenu:
                    SetupMainMenuScene();
                    break;
                case SceneType.Game:
                    SetupGameScene();
                    break;
            }
            
            Debug.Log($"[SceneSetupWizard] {selectedSceneType} scene setup complete!");
        }
        
        private void SetupMainMenuScene()
        {
            // Create camera
            CreateMainCamera();
            
            // Create managers
            if (createManagers)
            {
                CreateMainMenuManagers();
            }
            
            // Create UI
            if (createCanvas)
            {
                var canvas = CreateUICanvas("MainMenuCanvas");
                
                if (createPanels)
                {
                    CreateMainMenuPanels(canvas);
                }
            }
            
            if (createEventSystem)
            {
                CreateEventSystem();
            }
        }
        
        private void SetupGameScene()
        {
            // Create camera
            CreateMainCamera();
            
            // Create managers
            if (createManagers)
            {
                CreateGameManagers();
            }
            
            // Create UI
            if (createCanvas)
            {
                var canvas = CreateUICanvas("GameCanvas");
                
                if (createPanels)
                {
                    CreateGamePanels(canvas);
                }
            }
            
            if (createEventSystem)
            {
                CreateEventSystem();
            }
        }
        
        #region Camera & Core
        
        private void CreateMainCamera()
        {
            var cameraGO = new GameObject("Main Camera");
            var camera = cameraGO.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.1f, 0.1f, 0.15f);
            cameraGO.AddComponent<AudioListener>();
            cameraGO.tag = "MainCamera";
        }
        
        private void CreateEventSystem()
        {
            if (FindObjectOfType<UnityEngine.EventSystems.EventSystem>() == null)
            {
                var esGO = new GameObject("EventSystem");
                esGO.AddComponent<UnityEngine.EventSystems.EventSystem>();
                esGO.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
            }
        }
        
        #endregion
        
        #region Managers
        
        private void CreateMainMenuManagers()
        {
            // Bootstrapper (persistent)
            var bootstrapperGO = new GameObject("[SceneBootstrapper]");
            bootstrapperGO.AddComponent<Core.SceneBootstrapper>();
            
            // UI Manager holder
            var uiManagerGO = new GameObject("[UIManager]");
            // Add your UIManager component here when available
        }
        
        private void CreateGameManagers()
        {
            // Game Controller
            var gameControllerGO = new GameObject("[GameController]");
            gameControllerGO.AddComponent<Gameplay.GameSceneInitializer>();
            
            // Managers Container
            var managersGO = new GameObject("[Managers]");
            
            // Create child manager objects
            CreateChildManager(managersGO.transform, "TimeManager");
            CreateChildManager(managersGO.transform, "AIManager");
            CreateChildManager(managersGO.transform, "ScandalManager");
            CreateChildManager(managersGO.transform, "CrisisManager");
            CreateChildManager(managersGO.transform, "ElectionManager");
            CreateChildManager(managersGO.transform, "ResourceManager");
            CreateChildManager(managersGO.transform, "MediaManager");
            CreateChildManager(managersGO.transform, "NewsEventManager");
        }
        
        private GameObject CreateChildManager(Transform parent, string name)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent);
            return go;
        }
        
        #endregion
        
        #region UI Creation
        
        private Canvas CreateUICanvas(string name)
        {
            var canvasGO = new GameObject(name);
            var canvas = canvasGO.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            
            var scaler = canvasGO.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;
            
            canvasGO.AddComponent<GraphicRaycaster>();
            
            // Add PanelManager
            canvasGO.AddComponent<UI.PanelManager>();
            
            return canvas;
        }
        
        private void CreateMainMenuPanels(Canvas canvas)
        {
            // Main Menu Panel
            var mainMenuPanel = CreatePanel(canvas.transform, "MainMenuPanel");
            CreateButton(mainMenuPanel.transform, "NewCampaignButton", "New Campaign", new Vector2(0, 80));
            CreateButton(mainMenuPanel.transform, "ContinueButton", "Continue", new Vector2(0, 20));
            CreateButton(mainMenuPanel.transform, "LoadGameButton", "Load Game", new Vector2(0, -40));
            CreateButton(mainMenuPanel.transform, "SettingsButton", "Settings", new Vector2(0, -100));
            CreateButton(mainMenuPanel.transform, "QuitButton", "Quit", new Vector2(0, -160));
            
            // Character Creation Panel
            var charPanel = CreatePanel(canvas.transform, "CharacterCreationPanel");
            CreateButton(charPanel.transform, "RandomButton", "Random", new Vector2(-100, 0));
            CreateButton(charPanel.transform, "BuildButton", "Build", new Vector2(100, 0));
            CreateButton(charPanel.transform, "BackButton", "Back", new Vector2(0, -100));
            charPanel.SetActive(false);
            
            // Load Game Panel
            var loadPanel = CreatePanel(canvas.transform, "LoadGamePanel");
            CreateText(loadPanel.transform, "Title", "Load Game", new Vector2(0, 150));
            CreateButton(loadPanel.transform, "BackButton", "Back", new Vector2(0, -150));
            loadPanel.SetActive(false);
            
            // Settings Panel
            var settingsPanel = CreatePanel(canvas.transform, "SettingsPanel");
            CreateText(settingsPanel.transform, "Title", "Settings", new Vector2(0, 150));
            CreateButton(settingsPanel.transform, "BackButton", "Back", new Vector2(0, -150));
            settingsPanel.SetActive(false);
            
            // Add SimpleMainMenu script
            var menuScript = canvas.gameObject.AddComponent<UI.SimpleMainMenu>();
        }
        
        private void CreateGamePanels(Canvas canvas)
        {
            // Game HUD (always visible during gameplay)
            var hudPanel = CreatePanel(canvas.transform, "GameHUDPanel");
            CreateText(hudPanel.transform, "ResourcesLabel", "Resources: $0 | Trust: 50%", new Vector2(0, 200));
            CreateText(hudPanel.transform, "DateLabel", "January 2025", new Vector2(200, 200));
            
            // Pause Menu
            var pausePanel = CreatePanel(canvas.transform, "PauseMenuPanel");
            CreateText(pausePanel.transform, "Title", "PAUSED", new Vector2(0, 100));
            CreateButton(pausePanel.transform, "ResumeButton", "Resume", new Vector2(0, 20));
            CreateButton(pausePanel.transform, "SettingsButton", "Settings", new Vector2(0, -40));
            CreateButton(pausePanel.transform, "MainMenuButton", "Main Menu", new Vector2(0, -100));
            CreateButton(pausePanel.transform, "QuitButton", "Quit", new Vector2(0, -160));
            pausePanel.SetActive(false);
            
            // Event Popup
            var eventPanel = CreatePanel(canvas.transform, "EventPopupPanel");
            CreateText(eventPanel.transform, "Title", "Event Title", new Vector2(0, 100));
            CreateText(eventPanel.transform, "Description", "Event description goes here...", new Vector2(0, 0));
            CreateButton(eventPanel.transform, "Option1Button", "Option 1", new Vector2(-100, -100));
            CreateButton(eventPanel.transform, "Option2Button", "Option 2", new Vector2(100, -100));
            eventPanel.SetActive(false);
            
            // Scandal Response
            var scandalPanel = CreatePanel(canvas.transform, "ScandalResponsePanel");
            CreateText(scandalPanel.transform, "Title", "SCANDAL!", new Vector2(0, 100));
            CreateButton(scandalPanel.transform, "DenyButton", "Deny", new Vector2(-150, -100));
            CreateButton(scandalPanel.transform, "ApologizeButton", "Apologize", new Vector2(0, -100));
            CreateButton(scandalPanel.transform, "AttackButton", "Counter-Attack", new Vector2(150, -100));
            scandalPanel.SetActive(false);
            
            // Election Night
            var electionPanel = CreatePanel(canvas.transform, "ElectionNightPanel");
            CreateText(electionPanel.transform, "Title", "ELECTION NIGHT", new Vector2(0, 150));
            CreateText(electionPanel.transform, "Results", "Results loading...", new Vector2(0, 0));
            CreateButton(electionPanel.transform, "ContinueButton", "Continue", new Vector2(0, -150));
            electionPanel.SetActive(false);
        }
        
        private GameObject CreatePanel(Transform parent, string name)
        {
            var panelGO = new GameObject(name);
            panelGO.transform.SetParent(parent, false);
            
            var rectTransform = panelGO.AddComponent<RectTransform>();
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
            
            var image = panelGO.AddComponent<Image>();
            image.color = new Color(0.1f, 0.1f, 0.15f, 0.95f);
            
            var canvasGroup = panelGO.AddComponent<CanvasGroup>();
            
            return panelGO;
        }
        
        private GameObject CreateButton(Transform parent, string name, string text, Vector2 position)
        {
            var buttonGO = new GameObject(name);
            buttonGO.transform.SetParent(parent, false);
            
            var rectTransform = buttonGO.AddComponent<RectTransform>();
            rectTransform.sizeDelta = new Vector2(200, 50);
            rectTransform.anchoredPosition = position;
            
            var image = buttonGO.AddComponent<Image>();
            image.color = new Color(0.3f, 0.3f, 0.4f);
            
            var button = buttonGO.AddComponent<Button>();
            var colors = button.colors;
            colors.highlightedColor = new Color(0.4f, 0.4f, 0.5f);
            colors.pressedColor = new Color(0.2f, 0.2f, 0.3f);
            button.colors = colors;
            
            // Text child
            var textGO = new GameObject("Text");
            textGO.transform.SetParent(buttonGO.transform, false);
            
            var textRect = textGO.AddComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;
            
            // Try TMP first, fallback to legacy Text
            var tmpText = textGO.AddComponent<TextMeshProUGUI>();
            if (tmpText != null)
            {
                tmpText.text = text;
                tmpText.alignment = TextAlignmentOptions.Center;
                tmpText.color = Color.white;
                tmpText.fontSize = 24;
            }
            
            return buttonGO;
        }
        
        private GameObject CreateText(Transform parent, string name, string content, Vector2 position)
        {
            var textGO = new GameObject(name);
            textGO.transform.SetParent(parent, false);
            
            var rectTransform = textGO.AddComponent<RectTransform>();
            rectTransform.sizeDelta = new Vector2(400, 50);
            rectTransform.anchoredPosition = position;
            
            var tmpText = textGO.AddComponent<TextMeshProUGUI>();
            if (tmpText != null)
            {
                tmpText.text = content;
                tmpText.alignment = TextAlignmentOptions.Center;
                tmpText.color = Color.white;
                tmpText.fontSize = 32;
            }
            
            return textGO;
        }
        
        #endregion
    }
}
#endif
