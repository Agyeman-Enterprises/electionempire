using UnityEngine;

namespace ElectionEmpire.Core
{
    /// <summary>
    /// Constants for Election Empire layer masks and layer indices.
    /// Use these for consistent layer references throughout the codebase.
    /// </summary>
    public static class ElectionEmpireLayers
    {
        // ===== LAYER INDICES =====
        public const int Default = 0;
        public const int TransparentFX = 1;
        public const int IgnoreRaycast = 2;
        public const int Water = 4;
        public const int UI = 5;
        public const int Characters = 6;
        public const int Background = 7;
        public const int Midground = 8;
        public const int Foreground = 9;
        public const int Effects = 10;
        public const int Interactive = 11;
        public const int Popup = 12;
        public const int Modal = 13;
        public const int Overlay = 14;
        public const int Tooltip = 15;
        public const int Notification = 16;
        public const int Debug = 17;

        // ===== LAYER MASKS (for raycasting/culling) =====
        public static readonly int DefaultMask = 1 << Default;
        public static readonly int TransparentFXMask = 1 << TransparentFX;
        public static readonly int IgnoreRaycastMask = 1 << IgnoreRaycast;
        public static readonly int WaterMask = 1 << Water;
        public static readonly int UIMask = 1 << UI;
        public static readonly int CharactersMask = 1 << Characters;
        public static readonly int BackgroundMask = 1 << Background;
        public static readonly int MidgroundMask = 1 << Midground;
        public static readonly int ForegroundMask = 1 << Foreground;
        public static readonly int EffectsMask = 1 << Effects;
        public static readonly int InteractiveMask = 1 << Interactive;
        public static readonly int PopupMask = 1 << Popup;
        public static readonly int ModalMask = 1 << Modal;
        public static readonly int OverlayMask = 1 << Overlay;
        public static readonly int TooltipMask = 1 << Tooltip;
        public static readonly int NotificationMask = 1 << Notification;
        public static readonly int DebugMask = 1 << Debug;

        // ===== COMBINED MASKS =====
        
        /// <summary>
        /// All clickable/interactive layers for mouse/touch raycasting
        /// </summary>
        public static readonly int ClickableMask = InteractiveMask | CharactersMask | UIMask;
        
        /// <summary>
        /// All UI-related layers
        /// </summary>
        public static readonly int AllUIMask = UIMask | PopupMask | ModalMask | OverlayMask | TooltipMask | NotificationMask;
        
        /// <summary>
        /// All game world layers (non-UI)
        /// </summary>
        public static readonly int GameWorldMask = DefaultMask | CharactersMask | BackgroundMask | MidgroundMask | ForegroundMask | EffectsMask | InteractiveMask;
        
        /// <summary>
        /// Everything except debug layer
        /// </summary>
        public static readonly int EverythingExceptDebug = ~DebugMask;
        
        /// <summary>
        /// Main camera culling mask (game world + effects)
        /// </summary>
        public static readonly int MainCameraMask = GameWorldMask | EffectsMask;
        
        /// <summary>
        /// UI camera culling mask
        /// </summary>
        public static readonly int UICameraMask = AllUIMask;

        // ===== HELPER METHODS =====
        
        /// <summary>
        /// Sets the layer of a GameObject and all its children
        /// </summary>
        public static void SetLayerRecursively(GameObject obj, int layer)
        {
            if (obj == null) return;
            obj.layer = layer;
            foreach (Transform child in obj.transform)
            {
                SetLayerRecursively(child.gameObject, layer);
            }
        }
        
        /// <summary>
        /// Checks if a layer is included in a layer mask
        /// </summary>
        public static bool IsInLayerMask(int layer, int layerMask)
        {
            return (layerMask & (1 << layer)) != 0;
        }
        
        /// <summary>
        /// Gets layer mask from layer name (cached for performance)
        /// </summary>
        public static int GetLayerMask(string layerName)
        {
            return 1 << LayerMask.NameToLayer(layerName);
        }
    }

    /// <summary>
    /// Constants for Election Empire sorting layers.
    /// Use these for consistent sprite sorting throughout the codebase.
    /// </summary>
    public static class ElectionEmpireSortingLayers
    {
        // ===== SORTING LAYER NAMES =====
        public const string Default = "Default";
        public const string BackgroundFar = "Background_Far";
        public const string BackgroundNear = "Background_Near";
        public const string Environment = "Environment";
        public const string CharactersBack = "Characters_Back";
        public const string Characters = "Characters";
        public const string CharactersFront = "Characters_Front";
        public const string Foreground = "Foreground";
        public const string Effects = "Effects";
        public const string UIBackground = "UI_Background";
        public const string UIMain = "UI_Main";
        public const string UICards = "UI_Cards";
        public const string UIPopup = "UI_Popup";
        public const string UIModal = "UI_Modal";
        public const string UITooltip = "UI_Tooltip";
        public const string UINotification = "UI_Notification";
        public const string UIOverlay = "UI_Overlay";

        // ===== SORTING LAYER IDS (use SortingLayer.NameToID for runtime) =====
        
        /// <summary>
        /// Gets the sorting layer ID from name.
        /// Cache these at startup for performance.
        /// </summary>
        public static int GetID(string layerName)
        {
            return SortingLayer.NameToID(layerName);
        }
    }

    /// <summary>
    /// Constants for Election Empire tags.
    /// Use these for consistent tag references throughout the codebase.
    /// </summary>
    public static class ElectionEmpireTags
    {
        // ===== CHARACTER TAGS =====
        public const string Player = "Player";
        public const string NPC = "NPC";
        public const string Opponent = "Opponent";
        public const string Ally = "Ally";
        public const string Staff = "Staff";
        public const string VoterBloc = "VoterBloc";
        public const string Media = "Media";
        
        // ===== GAMEPLAY TAGS =====
        public const string Campaign = "Campaign";
        public const string Scandal = "Scandal";
        public const string Crisis = "Crisis";
        public const string Interactive = "Interactive";
        public const string Clickable = "Clickable";
        public const string Resource = "Resource";
        public const string Achievement = "Achievement";
        
        // ===== UI TAGS =====
        public const string Tooltip = "Tooltip";
        public const string Portrait = "Portrait";
        public const string Card = "Card";
        public const string Button = "Button";
        public const string Panel = "Panel";
        public const string Notification = "Notification";

        /// <summary>
        /// Checks if a GameObject has any of the character tags
        /// </summary>
        public static bool IsCharacter(GameObject obj)
        {
            return obj.CompareTag(Player) || 
                   obj.CompareTag(NPC) || 
                   obj.CompareTag(Opponent) || 
                   obj.CompareTag(Ally) || 
                   obj.CompareTag(Staff);
        }
        
        /// <summary>
        /// Checks if a GameObject is interactive
        /// </summary>
        public static bool IsInteractive(GameObject obj)
        {
            return obj.CompareTag(Interactive) || obj.CompareTag(Clickable);
        }
    }
}
