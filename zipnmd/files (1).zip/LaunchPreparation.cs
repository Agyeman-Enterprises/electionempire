// ═══════════════════════════════════════════════════════════════════════════════
// ELECTION EMPIRE - Launch Preparation Systems
// Sprint 12: Steam integration, build pipeline, localization, launch checklist
// ═══════════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace ElectionEmpire.Launch
{
    #region Steam Integration
    
    /// <summary>
    /// Steam achievement definition.
    /// </summary>
    [Serializable]
    public class SteamAchievementDef
    {
        public string ApiName;
        public string DisplayName;
        public string Description;
        public string IconPath;
        public string IconGrayPath;
        public bool IsHidden;
        public int SortOrder;
    }
    
    /// <summary>
    /// Steam stat definition.
    /// </summary>
    [Serializable]
    public class SteamStatDef
    {
        public string ApiName;
        public string DisplayName;
        public int DefaultValue;
        public int MinValue;
        public int MaxValue;
        public bool IncrementOnly;
    }
    
    /// <summary>
    /// Steam leaderboard definition.
    /// </summary>
    [Serializable]
    public class SteamLeaderboardDef
    {
        public string Name;
        public string DisplayName;
        public string SortMethod;       // Ascending or Descending
        public string DisplayType;      // Numeric, Seconds, Milliseconds
    }
    
    /// <summary>
    /// Manages Steam platform integration.
    /// </summary>
    public class SteamManager : MonoBehaviour
    {
        private static SteamManager instance;
        public static SteamManager Instance => instance;
        
        [Header("Configuration")]
        [SerializeField] private uint appId = 0; // Set in inspector or via config
        
        private bool isInitialized;
        private string playerName;
        private ulong steamId;
        
        // Achievement cache
        private Dictionary<string, bool> achievementCache;
        private Dictionary<string, int> statCache;
        
        // Events
        public event Action OnSteamInitialized;
        public event Action<string> OnAchievementUnlocked;
        public event Action<string, int> OnStatUpdated;
        
        public bool IsInitialized => isInitialized;
        public string PlayerName => playerName;
        public ulong SteamId => steamId;
        
        #region Initialization
        
        private void Awake()
        {
            if (instance != null && instance != this)
            {
                Destroy(gameObject);
                return;
            }
            
            instance = this;
            DontDestroyOnLoad(gameObject);
            
            achievementCache = new Dictionary<string, bool>();
            statCache = new Dictionary<string, int>();
        }
        
        private void Start()
        {
            InitializeSteam();
        }
        
        private void InitializeSteam()
        {
            // In production, this would use Steamworks.NET
            // For now, simulate initialization
            
            Debug.Log("[Steam] Initializing Steam API...");
            
            try
            {
                // Steamworks.SteamClient.Init(appId);
                
                isInitialized = true;
                playerName = "TestPlayer"; // SteamClient.Name
                steamId = 76561198000000000; // SteamClient.SteamId
                
                Debug.Log($"[Steam] Initialized for user: {playerName}");
                
                // Load cached achievements and stats
                LoadAchievements();
                LoadStats();
                
                OnSteamInitialized?.Invoke();
            }
            catch (Exception e)
            {
                Debug.LogError($"[Steam] Failed to initialize: {e.Message}");
                isInitialized = false;
            }
        }
        
        private void OnDestroy()
        {
            if (isInitialized)
            {
                // Steamworks.SteamClient.Shutdown();
                Debug.Log("[Steam] Shutdown complete");
            }
            
            if (instance == this)
            {
                instance = null;
            }
        }
        
        #endregion
        
        #region Achievements
        
        private void LoadAchievements()
        {
            // Would load from Steam API
            achievementCache.Clear();
            
            // Populate with known achievements
            string[] achievementIds = 
            {
                "ACH_FIRST_CAMPAIGN",
                "ACH_UNDERDOG",
                "ACH_LANDSLIDE",
                "ACH_PRESIDENT",
                "ACH_CLEAN",
                "ACH_APPROVAL_KING",
                "ACH_CHAOS",
                "ACH_DRUNK",
                "ACH_ALL_ALIGNMENTS",
                "ACH_SECRET_SUPREME",
                "ACH_SECRET_SHADOW"
            };
            
            foreach (var id in achievementIds)
            {
                // bool unlocked = Steamworks.SteamUserStats.GetAchievement(id);
                achievementCache[id] = false; // Would be actual value
            }
        }
        
        public bool IsAchievementUnlocked(string achievementId)
        {
            return achievementCache.TryGetValue(achievementId, out var unlocked) && unlocked;
        }
        
        public void UnlockAchievement(string achievementId)
        {
            if (!isInitialized) return;
            if (IsAchievementUnlocked(achievementId)) return;
            
            Debug.Log($"[Steam] Unlocking achievement: {achievementId}");
            
            // Steamworks.SteamUserStats.SetAchievement(achievementId);
            // Steamworks.SteamUserStats.StoreStats();
            
            achievementCache[achievementId] = true;
            OnAchievementUnlocked?.Invoke(achievementId);
        }
        
        public void ClearAchievement(string achievementId)
        {
            if (!isInitialized) return;
            
            // For development/testing only
            // Steamworks.SteamUserStats.ClearAchievement(achievementId);
            achievementCache[achievementId] = false;
        }
        
        public float GetGlobalAchievementPercent(string achievementId)
        {
            // Steamworks.SteamUserStats.GetAchievementAchievedPercent(achievementId)
            return 0f;
        }
        
        #endregion
        
        #region Stats
        
        private void LoadStats()
        {
            statCache.Clear();
            
            string[] statIds = 
            {
                "STAT_ELECTIONS_WON",
                "STAT_ELECTIONS_LOST",
                "STAT_SCANDALS_SURVIVED",
                "STAT_CRISES_RESOLVED",
                "STAT_HIGHEST_TIER",
                "STAT_TOTAL_PLAYTIME",
                "STAT_DIRTY_TRICKS_USED",
                "STAT_POLICIES_PASSED"
            };
            
            foreach (var id in statIds)
            {
                // int value = Steamworks.SteamUserStats.GetStatInt(id);
                statCache[id] = 0;
            }
        }
        
        public int GetStat(string statId)
        {
            return statCache.TryGetValue(statId, out var value) ? value : 0;
        }
        
        public void SetStat(string statId, int value)
        {
            if (!isInitialized) return;
            
            // Steamworks.SteamUserStats.SetStat(statId, value);
            statCache[statId] = value;
            OnStatUpdated?.Invoke(statId, value);
        }
        
        public void IncrementStat(string statId, int amount = 1)
        {
            int current = GetStat(statId);
            SetStat(statId, current + amount);
        }
        
        public void StorStats()
        {
            if (!isInitialized) return;
            // Steamworks.SteamUserStats.StoreStats();
        }
        
        #endregion
        
        #region Leaderboards
        
        public async Task<bool> SubmitScore(string leaderboardName, int score)
        {
            if (!isInitialized) return false;
            
            Debug.Log($"[Steam] Submitting score {score} to {leaderboardName}");
            
            // var leaderboard = await Steamworks.SteamUserStats.FindLeaderboardAsync(leaderboardName);
            // var result = await leaderboard.Value.SubmitScoreAsync(score);
            
            await Task.Delay(100); // Simulate async
            return true;
        }
        
        public async Task<List<LeaderboardEntry>> GetLeaderboardEntries(
            string leaderboardName, 
            int start = 0, 
            int count = 10)
        {
            if (!isInitialized) return new List<LeaderboardEntry>();
            
            // var leaderboard = await Steamworks.SteamUserStats.FindLeaderboardAsync(leaderboardName);
            // var entries = await leaderboard.Value.GetScoresAsync(count, start);
            
            await Task.Delay(100);
            return new List<LeaderboardEntry>();
        }
        
        #endregion
        
        #region Rich Presence
        
        public void SetRichPresence(string key, string value)
        {
            if (!isInitialized) return;
            
            // Steamworks.SteamFriends.SetRichPresence(key, value);
            Debug.Log($"[Steam] Rich presence: {key} = {value}");
        }
        
        public void SetPlayingStatus(string office, int tier, string phase)
        {
            SetRichPresence("status", $"Playing as {office}");
            SetRichPresence("tier", tier.ToString());
            SetRichPresence("phase", phase);
        }
        
        public void ClearRichPresence()
        {
            // Steamworks.SteamFriends.ClearRichPresence();
        }
        
        #endregion
        
        #region Cloud Save
        
        public bool CloudSaveEnabled => isInitialized; // && Steamworks.SteamRemoteStorage.IsCloudEnabled
        
        public bool SaveToCloud(string filename, byte[] data)
        {
            if (!CloudSaveEnabled) return false;
            
            // return Steamworks.SteamRemoteStorage.FileWrite(filename, data);
            Debug.Log($"[Steam] Saving {data.Length} bytes to cloud: {filename}");
            return true;
        }
        
        public byte[] LoadFromCloud(string filename)
        {
            if (!CloudSaveEnabled) return null;
            
            // return Steamworks.SteamRemoteStorage.FileRead(filename);
            return null;
        }
        
        public bool CloudFileExists(string filename)
        {
            // return Steamworks.SteamRemoteStorage.FileExists(filename);
            return false;
        }
        
        public void DeleteCloudFile(string filename)
        {
            // Steamworks.SteamRemoteStorage.FileDelete(filename);
        }
        
        #endregion
    }
    
    /// <summary>
    /// Leaderboard entry data.
    /// </summary>
    [Serializable]
    public class LeaderboardEntry
    {
        public int Rank;
        public string PlayerName;
        public ulong SteamId;
        public int Score;
        public DateTime SubmitTime;
    }
    
    #endregion
    
    #region Localization System
    
    /// <summary>
    /// Supported languages.
    /// </summary>
    public enum GameLanguage
    {
        English,
        Spanish,
        French,
        German,
        Italian,
        Portuguese,
        Russian,
        Chinese_Simplified,
        Chinese_Traditional,
        Japanese,
        Korean
    }
    
    /// <summary>
    /// Localized string entry.
    /// </summary>
    [Serializable]
    public class LocalizedString
    {
        public string Key;
        public Dictionary<GameLanguage, string> Translations;
        
        public LocalizedString()
        {
            Translations = new Dictionary<GameLanguage, string>();
        }
        
        public string Get(GameLanguage language)
        {
            if (Translations.TryGetValue(language, out var value))
            {
                return value;
            }
            
            // Fallback to English
            if (Translations.TryGetValue(GameLanguage.English, out var english))
            {
                return english;
            }
            
            return $"[{Key}]";
        }
    }
    
    /// <summary>
    /// Localization table for a category.
    /// </summary>
    [Serializable]
    public class LocalizationTable
    {
        public string TableId;
        public string Category;
        public Dictionary<string, LocalizedString> Entries;
        
        public LocalizationTable()
        {
            Entries = new Dictionary<string, LocalizedString>();
        }
    }
    
    /// <summary>
    /// Manages game localization.
    /// </summary>
    public class LocalizationManager
    {
        private static LocalizationManager instance;
        public static LocalizationManager Instance => instance ??= new LocalizationManager();
        
        private GameLanguage currentLanguage = GameLanguage.English;
        private Dictionary<string, LocalizationTable> tables;
        private Dictionary<string, string> flattenedStrings;
        
        public event Action<GameLanguage> OnLanguageChanged;
        
        public GameLanguage CurrentLanguage => currentLanguage;
        
        private LocalizationManager()
        {
            tables = new Dictionary<string, LocalizationTable>();
            flattenedStrings = new Dictionary<string, string>();
            
            LoadAllTables();
            DetectSystemLanguage();
        }
        
        #region Language Detection
        
        private void DetectSystemLanguage()
        {
            var systemLang = Application.systemLanguage;
            
            currentLanguage = systemLang switch
            {
                SystemLanguage.Spanish => GameLanguage.Spanish,
                SystemLanguage.French => GameLanguage.French,
                SystemLanguage.German => GameLanguage.German,
                SystemLanguage.Italian => GameLanguage.Italian,
                SystemLanguage.Portuguese => GameLanguage.Portuguese,
                SystemLanguage.Russian => GameLanguage.Russian,
                SystemLanguage.Chinese => GameLanguage.Chinese_Simplified,
                SystemLanguage.ChineseSimplified => GameLanguage.Chinese_Simplified,
                SystemLanguage.ChineseTraditional => GameLanguage.Chinese_Traditional,
                SystemLanguage.Japanese => GameLanguage.Japanese,
                SystemLanguage.Korean => GameLanguage.Korean,
                _ => GameLanguage.English
            };
            
            // Check for saved preference
            string savedLang = PlayerPrefs.GetString("Language", "");
            if (!string.IsNullOrEmpty(savedLang) && Enum.TryParse<GameLanguage>(savedLang, out var parsed))
            {
                currentLanguage = parsed;
            }
            
            RebuildFlattenedStrings();
        }
        
        public void SetLanguage(GameLanguage language)
        {
            if (language == currentLanguage) return;
            
            currentLanguage = language;
            PlayerPrefs.SetString("Language", language.ToString());
            PlayerPrefs.Save();
            
            RebuildFlattenedStrings();
            OnLanguageChanged?.Invoke(language);
        }
        
        #endregion
        
        #region Table Loading
        
        private void LoadAllTables()
        {
            // Load from Resources or streaming assets
            LoadTable("UI");
            LoadTable("Gameplay");
            LoadTable("Characters");
            LoadTable("Events");
            LoadTable("Scandals");
            LoadTable("Achievements");
        }
        
        private void LoadTable(string tableId)
        {
            var table = new LocalizationTable
            {
                TableId = tableId,
                Category = tableId
            };
            
            // In production, load from JSON/CSV files
            // For now, initialize with sample data
            InitializeSampleStrings(table);
            
            tables[tableId] = table;
        }
        
        private void InitializeSampleStrings(LocalizationTable table)
        {
            switch (table.TableId)
            {
                case "UI":
                    AddString(table, "ui.main_menu.new_game", "New Game", "Nuevo Juego", "Nouveau Jeu", "Neues Spiel");
                    AddString(table, "ui.main_menu.continue", "Continue", "Continuar", "Continuer", "Fortsetzen");
                    AddString(table, "ui.main_menu.settings", "Settings", "Configuración", "Paramètres", "Einstellungen");
                    AddString(table, "ui.main_menu.quit", "Quit", "Salir", "Quitter", "Beenden");
                    AddString(table, "ui.pause.resume", "Resume", "Reanudar", "Reprendre", "Fortsetzen");
                    AddString(table, "ui.pause.save", "Save Game", "Guardar", "Sauvegarder", "Speichern");
                    AddString(table, "ui.pause.load", "Load Game", "Cargar", "Charger", "Laden");
                    AddString(table, "ui.pause.main_menu", "Main Menu", "Menú Principal", "Menu Principal", "Hauptmenü");
                    break;
                    
                case "Gameplay":
                    AddString(table, "game.phase.campaign", "Campaign Phase", "Fase de Campaña", "Phase de Campagne", "Wahlkampfphase");
                    AddString(table, "game.phase.governance", "Governance Phase", "Fase de Gobierno", "Phase de Gouvernance", "Regierungsphase");
                    AddString(table, "game.phase.election", "Election Day", "Día de Elecciones", "Jour d'Élection", "Wahltag");
                    AddString(table, "game.resource.trust", "Public Trust", "Confianza Pública", "Confiance Publique", "Öffentliches Vertrauen");
                    AddString(table, "game.resource.funds", "Campaign Funds", "Fondos de Campaña", "Fonds de Campagne", "Wahlkampfmittel");
                    AddString(table, "game.resource.capital", "Political Capital", "Capital Político", "Capital Politique", "Politisches Kapital");
                    break;
                    
                case "Characters":
                    AddString(table, "bg.businessman.name", "Businessman", "Empresario", "Homme d'Affaires", "Geschäftsmann");
                    AddString(table, "bg.politician.name", "Local Politician", "Político Local", "Politicien Local", "Lokalpolitiker");
                    AddString(table, "bg.teacher.name", "Teacher", "Maestro", "Enseignant", "Lehrer");
                    AddString(table, "bg.doctor.name", "Doctor", "Doctor", "Docteur", "Arzt");
                    AddString(table, "bg.police.name", "Police Officer", "Oficial de Policía", "Officier de Police", "Polizist");
                    AddString(table, "bg.journalist.name", "Journalist", "Periodista", "Journaliste", "Journalist");
                    AddString(table, "bg.activist.name", "Activist", "Activista", "Activiste", "Aktivist");
                    AddString(table, "bg.religious.name", "Religious Leader", "Líder Religioso", "Chef Religieux", "Religiöser Führer");
                    break;
                    
                case "Achievements":
                    AddString(table, "ach.first_campaign", "The Journey Begins", "El Viaje Comienza", "Le Voyage Commence", "Die Reise Beginnt");
                    AddString(table, "ach.president", "Mr./Madam President", "Sr./Sra. Presidente", "M./Mme le Président", "Herr/Frau Präsident");
                    AddString(table, "ach.chaos", "Chaos Champion", "Campeón del Caos", "Champion du Chaos", "Chaos-Champion");
                    break;
            }
        }
        
        private void AddString(LocalizationTable table, string key, string en, string es = null, string fr = null, string de = null)
        {
            var locString = new LocalizedString { Key = key };
            locString.Translations[GameLanguage.English] = en;
            if (es != null) locString.Translations[GameLanguage.Spanish] = es;
            if (fr != null) locString.Translations[GameLanguage.French] = fr;
            if (de != null) locString.Translations[GameLanguage.German] = de;
            
            table.Entries[key] = locString;
        }
        
        private void RebuildFlattenedStrings()
        {
            flattenedStrings.Clear();
            
            foreach (var table in tables.Values)
            {
                foreach (var entry in table.Entries)
                {
                    flattenedStrings[entry.Key] = entry.Value.Get(currentLanguage);
                }
            }
        }
        
        #endregion
        
        #region String Access
        
        public string Get(string key)
        {
            if (flattenedStrings.TryGetValue(key, out var value))
            {
                return value;
            }
            return $"[{key}]";
        }
        
        public string Get(string key, params object[] args)
        {
            string template = Get(key);
            
            try
            {
                return string.Format(template, args);
            }
            catch
            {
                return template;
            }
        }
        
        public bool HasKey(string key)
        {
            return flattenedStrings.ContainsKey(key);
        }
        
        #endregion
        
        #region Available Languages
        
        public GameLanguage[] GetAvailableLanguages()
        {
            return (GameLanguage[])Enum.GetValues(typeof(GameLanguage));
        }
        
        public string GetLanguageDisplayName(GameLanguage language)
        {
            return language switch
            {
                GameLanguage.English => "English",
                GameLanguage.Spanish => "Español",
                GameLanguage.French => "Français",
                GameLanguage.German => "Deutsch",
                GameLanguage.Italian => "Italiano",
                GameLanguage.Portuguese => "Português",
                GameLanguage.Russian => "Русский",
                GameLanguage.Chinese_Simplified => "简体中文",
                GameLanguage.Chinese_Traditional => "繁體中文",
                GameLanguage.Japanese => "日本語",
                GameLanguage.Korean => "한국어",
                _ => language.ToString()
            };
        }
        
        #endregion
    }
    
    /// <summary>
    /// Helper for localized text in UI.
    /// </summary>
    public static class L
    {
        public static string Get(string key) => LocalizationManager.Instance.Get(key);
        public static string Get(string key, params object[] args) => LocalizationManager.Instance.Get(key, args);
    }
    
    #endregion
    
    #region Build Pipeline
    
    /// <summary>
    /// Build configuration.
    /// </summary>
    [Serializable]
    public class BuildConfig
    {
        public string BuildName;
        public string Version;
        public int BuildNumber;
        public BuildTarget Target;
        public bool DevelopmentBuild;
        public bool IncludeDebugSymbols;
        public string OutputPath;
        public string[] Scenes;
        public string[] DefineSymbols;
        public Dictionary<string, string> BuildOptions;
    }
    
    /// <summary>
    /// Build targets.
    /// </summary>
    public enum BuildTarget
    {
        Windows64,
        MacOS,
        Linux,
        WebGL,
        iOS,
        Android
    }
    
    /// <summary>
    /// Build result.
    /// </summary>
    [Serializable]
    public class BuildResult
    {
        public bool Success;
        public string OutputPath;
        public long FileSizeBytes;
        public TimeSpan BuildDuration;
        public List<string> Warnings;
        public List<string> Errors;
        public DateTime BuildTime;
    }
    
    /// <summary>
    /// Manages build pipeline operations.
    /// </summary>
    public static class BuildPipeline
    {
        private static readonly string[] DefaultScenes =
        {
            "Assets/Scenes/Bootstrap.unity",
            "Assets/Scenes/MainMenu.unity",
            "Assets/Scenes/CharacterCreation.unity",
            "Assets/Scenes/Gameplay.unity",
            "Assets/Scenes/Election.unity",
            "Assets/Scenes/GameOver.unity"
        };
        
        public static BuildConfig CreateDefaultConfig(BuildTarget target, string version)
        {
            return new BuildConfig
            {
                BuildName = "ElectionEmpire",
                Version = version,
                BuildNumber = GetNextBuildNumber(),
                Target = target,
                DevelopmentBuild = false,
                IncludeDebugSymbols = false,
                OutputPath = GetDefaultOutputPath(target),
                Scenes = DefaultScenes,
                DefineSymbols = GetDefaultDefineSymbols(target),
                BuildOptions = new Dictionary<string, string>()
            };
        }
        
        private static int GetNextBuildNumber()
        {
            int current = PlayerPrefs.GetInt("BuildNumber", 0);
            PlayerPrefs.SetInt("BuildNumber", current + 1);
            PlayerPrefs.Save();
            return current + 1;
        }
        
        private static string GetDefaultOutputPath(BuildTarget target)
        {
            string basePath = "Builds/";
            
            return target switch
            {
                BuildTarget.Windows64 => basePath + "Windows/ElectionEmpire.exe",
                BuildTarget.MacOS => basePath + "MacOS/ElectionEmpire.app",
                BuildTarget.Linux => basePath + "Linux/ElectionEmpire",
                BuildTarget.WebGL => basePath + "WebGL/",
                BuildTarget.iOS => basePath + "iOS/",
                BuildTarget.Android => basePath + "Android/ElectionEmpire.apk",
                _ => basePath + "Unknown/"
            };
        }
        
        private static string[] GetDefaultDefineSymbols(BuildTarget target)
        {
            var symbols = new List<string> { "RELEASE" };
            
            switch (target)
            {
                case BuildTarget.Windows64:
                case BuildTarget.MacOS:
                case BuildTarget.Linux:
                    symbols.Add("STEAM");
                    break;
                    
                case BuildTarget.iOS:
                case BuildTarget.Android:
                    symbols.Add("MOBILE");
                    symbols.Add("IAP_ENABLED");
                    break;
            }
            
            return symbols.ToArray();
        }
        
        public static BuildResult Build(BuildConfig config)
        {
            var result = new BuildResult
            {
                BuildTime = DateTime.UtcNow,
                Warnings = new List<string>(),
                Errors = new List<string>()
            };
            
            var startTime = DateTime.Now;
            
            Debug.Log($"[Build] Starting build: {config.BuildName} v{config.Version} for {config.Target}");
            
            try
            {
                // In production, this would use UnityEditor.BuildPipeline
                // Simulate build process
                
                ValidateBuildConfig(config, result);
                
                if (result.Errors.Count > 0)
                {
                    result.Success = false;
                    return result;
                }
                
                // Actual build would happen here
                Debug.Log($"[Build] Building to: {config.OutputPath}");
                
                result.Success = true;
                result.OutputPath = config.OutputPath;
                result.FileSizeBytes = 1024 * 1024 * 500; // Simulated 500MB
            }
            catch (Exception e)
            {
                result.Success = false;
                result.Errors.Add(e.Message);
            }
            
            result.BuildDuration = DateTime.Now - startTime;
            
            Debug.Log($"[Build] Build {(result.Success ? "succeeded" : "failed")} in {result.BuildDuration.TotalSeconds:F1}s");
            
            return result;
        }
        
        private static void ValidateBuildConfig(BuildConfig config, BuildResult result)
        {
            if (string.IsNullOrEmpty(config.Version))
            {
                result.Errors.Add("Version is required");
            }
            
            if (config.Scenes == null || config.Scenes.Length == 0)
            {
                result.Errors.Add("At least one scene is required");
            }
            
            if (string.IsNullOrEmpty(config.OutputPath))
            {
                result.Errors.Add("Output path is required");
            }
        }
    }
    
    #endregion
    
    #region Launch Checklist
    
    /// <summary>
    /// Launch checklist item.
    /// </summary>
    [Serializable]
    public class ChecklistItem
    {
        public string Id;
        public string Category;
        public string Description;
        public string Details;
        public bool IsComplete;
        public bool IsBlocking;
        public string[] Dependencies;
        public DateTime? CompletedDate;
        public string CompletedBy;
    }
    
    /// <summary>
    /// Pre-launch checklist manager.
    /// </summary>
    public class LaunchChecklist
    {
        private List<ChecklistItem> items;
        
        public LaunchChecklist()
        {
            items = new List<ChecklistItem>();
            InitializeChecklist();
        }
        
        private void InitializeChecklist()
        {
            // ═══════════════════════════════════════════════════════════════
            // CODE COMPLETE
            // ═══════════════════════════════════════════════════════════════
            
            AddItem("code_core_systems", "Code", "Core game systems complete", 
                "Character, resources, elections, scandals, crises", true);
            
            AddItem("code_ai_opponents", "Code", "AI opponent systems complete",
                "Personality-driven AI, adaptive strategies", true);
            
            AddItem("code_chaos_mode", "Code", "Chaos Mode implemented",
                "All chaos events, viral mechanics, drunk state", true);
            
            AddItem("code_multiplayer", "Code", "Multiplayer foundation complete",
                "Networking, lobbies, state sync", true);
            
            AddItem("code_monetization", "Code", "Monetization systems complete",
                "IAP, currencies, cosmetics shop", true);
            
            AddItem("code_save_system", "Code", "Save/load system complete",
                "Local saves, cloud sync, autosave", true);
            
            AddItem("code_achievements", "Code", "Achievement system complete",
                "All achievements, Steam integration", true);
            
            // ═══════════════════════════════════════════════════════════════
            // CONTENT
            // ═══════════════════════════════════════════════════════════════
            
            AddItem("content_backgrounds", "Content", "All character backgrounds complete",
                "8 backgrounds with unique abilities", true);
            
            AddItem("content_events", "Content", "Event library complete",
                "200+ procedural events across categories", false);
            
            AddItem("content_scandals", "Content", "Scandal templates complete",
                "50+ scandal types with evolution paths", false);
            
            AddItem("content_dialogue", "Content", "Dialogue/text content complete",
                "All UI text, tooltips, descriptions", false);
            
            AddItem("content_tutorials", "Content", "Tutorial sequences complete",
                "Basic, advanced, and contextual tutorials", false);
            
            // ═══════════════════════════════════════════════════════════════
            // ART
            // ═══════════════════════════════════════════════════════════════
            
            AddItem("art_ui", "Art", "UI art assets complete",
                "All screens, buttons, icons, panels", true, new[] { "content_dialogue" });
            
            AddItem("art_portraits", "Art", "Character portrait system complete",
                "Procedural generation, expressions, effects", true);
            
            AddItem("art_backgrounds", "Art", "Background art complete",
                "All scene backgrounds, parallax layers", false);
            
            AddItem("art_cosmetics", "Art", "Cosmetic items art complete",
                "All purchasable cosmetic content", false);
            
            AddItem("art_animations", "Art", "UI animations complete",
                "Transitions, effects, victory/defeat", false);
            
            // ═══════════════════════════════════════════════════════════════
            // AUDIO
            // ═══════════════════════════════════════════════════════════════
            
            AddItem("audio_music", "Audio", "Music tracks complete",
                "All game state music, 10+ tracks", false);
            
            AddItem("audio_sfx", "Audio", "Sound effects complete",
                "All UI and gameplay SFX, 100+ sounds", false);
            
            AddItem("audio_ambience", "Audio", "Ambient audio complete",
                "Background ambience for all scenes", false);
            
            // ═══════════════════════════════════════════════════════════════
            // TESTING
            // ═══════════════════════════════════════════════════════════════
            
            AddItem("test_functional", "Testing", "Functional testing complete",
                "All features tested and verified", true, new[] { "code_core_systems" });
            
            AddItem("test_balance", "Testing", "Balance testing complete",
                "Difficulty curves, resource economy verified", false);
            
            AddItem("test_performance", "Testing", "Performance testing complete",
                "FPS targets met on minimum spec", true);
            
            AddItem("test_localization", "Testing", "Localization testing complete",
                "All languages verified", false);
            
            AddItem("test_multiplayer", "Testing", "Multiplayer testing complete",
                "Network stability, sync verified", false);
            
            // ═══════════════════════════════════════════════════════════════
            // PLATFORM
            // ═══════════════════════════════════════════════════════════════
            
            AddItem("platform_steam", "Platform", "Steam integration complete",
                "Achievements, cloud saves, rich presence", true);
            
            AddItem("platform_store_page", "Platform", "Steam store page ready",
                "Screenshots, description, tags, trailer", false);
            
            AddItem("platform_achievements_art", "Platform", "Achievement icons ready",
                "All achievement images uploaded", false);
            
            AddItem("platform_trading_cards", "Platform", "Trading cards ready",
                "Card art, badges, emoticons (optional)", false);
            
            // ═══════════════════════════════════════════════════════════════
            // LEGAL/BUSINESS
            // ═══════════════════════════════════════════════════════════════
            
            AddItem("legal_eula", "Legal", "EULA finalized",
                "End user license agreement approved", false);
            
            AddItem("legal_privacy", "Legal", "Privacy policy complete",
                "GDPR/CCPA compliant privacy policy", false);
            
            AddItem("legal_age_rating", "Legal", "Age rating obtained",
                "ESRB/PEGI rating process complete", false);
            
            AddItem("business_pricing", "Business", "Pricing finalized",
                "Base game and DLC pricing set", false);
            
            AddItem("business_marketing", "Business", "Marketing materials ready",
                "Press kit, trailers, screenshots", false);
        }
        
        private void AddItem(string id, string category, string description, 
            string details, bool isBlocking, string[] dependencies = null)
        {
            items.Add(new ChecklistItem
            {
                Id = id,
                Category = category,
                Description = description,
                Details = details,
                IsBlocking = isBlocking,
                Dependencies = dependencies ?? Array.Empty<string>()
            });
        }
        
        public void MarkComplete(string itemId, string completedBy = null)
        {
            var item = items.Find(i => i.Id == itemId);
            if (item != null)
            {
                item.IsComplete = true;
                item.CompletedDate = DateTime.UtcNow;
                item.CompletedBy = completedBy;
            }
        }
        
        public List<ChecklistItem> GetItemsByCategory(string category)
        {
            return items.Where(i => i.Category == category).ToList();
        }
        
        public List<ChecklistItem> GetBlockingItems()
        {
            return items.Where(i => i.IsBlocking && !i.IsComplete).ToList();
        }
        
        public List<ChecklistItem> GetReadyItems()
        {
            return items.Where(i => !i.IsComplete && AreDependenciesMet(i)).ToList();
        }
        
        private bool AreDependenciesMet(ChecklistItem item)
        {
            if (item.Dependencies == null || item.Dependencies.Length == 0)
            {
                return true;
            }
            
            return item.Dependencies.All(depId => 
                items.Any(i => i.Id == depId && i.IsComplete));
        }
        
        public float GetCompletionPercent()
        {
            if (items.Count == 0) return 0f;
            return (float)items.Count(i => i.IsComplete) / items.Count;
        }
        
        public float GetCompletionPercent(string category)
        {
            var categoryItems = items.Where(i => i.Category == category).ToList();
            if (categoryItems.Count == 0) return 0f;
            return (float)categoryItems.Count(i => i.IsComplete) / categoryItems.Count;
        }
        
        public bool IsReadyForLaunch()
        {
            return !items.Any(i => i.IsBlocking && !i.IsComplete);
        }
        
        public string GenerateReport()
        {
            var sb = new System.Text.StringBuilder();
            
            sb.AppendLine("═══════════════════════════════════════════════════════════════");
            sb.AppendLine("ELECTION EMPIRE - LAUNCH READINESS REPORT");
            sb.AppendLine($"Generated: {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC");
            sb.AppendLine("═══════════════════════════════════════════════════════════════");
            sb.AppendLine();
            
            sb.AppendLine($"Overall Completion: {GetCompletionPercent() * 100:F1}%");
            sb.AppendLine($"Ready for Launch: {(IsReadyForLaunch() ? "YES" : "NO")}");
            sb.AppendLine();
            
            var categories = items.Select(i => i.Category).Distinct();
            
            foreach (var category in categories)
            {
                sb.AppendLine($"--- {category.ToUpper()} ({GetCompletionPercent(category) * 100:F0}%) ---");
                
                foreach (var item in GetItemsByCategory(category))
                {
                    string status = item.IsComplete ? "[X]" : "[ ]";
                    string blocking = item.IsBlocking ? "*" : " ";
                    sb.AppendLine($"  {status}{blocking} {item.Description}");
                    
                    if (!item.IsComplete && item.Details != null)
                    {
                        sb.AppendLine($"      {item.Details}");
                    }
                }
                
                sb.AppendLine();
            }
            
            var blockingItems = GetBlockingItems();
            if (blockingItems.Count > 0)
            {
                sb.AppendLine("═══════════════════════════════════════════════════════════════");
                sb.AppendLine("BLOCKING ITEMS (Must complete before launch):");
                sb.AppendLine("═══════════════════════════════════════════════════════════════");
                
                foreach (var item in blockingItems)
                {
                    sb.AppendLine($"  - {item.Description}");
                }
            }
            
            return sb.ToString();
        }
    }
    
    #endregion
}
